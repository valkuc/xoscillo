All the info you need is here:

http://code.google.com/p/xoscillo/

Thanks!